# devops-ps-cf
devops-pluralsight-cloudformation
